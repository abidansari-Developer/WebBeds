﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using WebApplication1.Models;

namespace WebApplication1.Common
{
    public class BasicMethod
    {

        /// <summary>
        /// CallApiService service is as a common for retival
        /// </summary>
        /// <param name="url"></param>
        /// <param name="destinationId"></param>
        /// <param name="nights"></param>
        /// <param name="code"></param>
        /// <returns></returns>
        public async Task<List<WebbedModel>> CallApiService(string url, int destinationId, int nights, string code)
        {
            HttpClient client = new HttpClient();
            List<WebbedModel> lstWebbedModels = new List<WebbedModel>();
            try
            {
                var response = await client.GetAsync(url + $"?destinationId={destinationId}&nights={nights}&code={code}");
                if (response.IsSuccessStatusCode)
                {
                    var result = await response.Content.ReadAsStringAsync();
                    // var webbedDataCollection = JObject.Parse(result).ToString();
                    if (!string.IsNullOrWhiteSpace(result))
                    {
                        lstWebbedModels = JsonConvert.DeserializeObject<List<WebbedModel>>(result);
                    }
                }
                else
                {
                    //Temporary use mock because API service is not working//
                    lstWebbedModels = mockData();

                    //Console.WriteLine($"Error: {response.ReasonPhrase}");
                    //return null;
                }
            }
            catch (HttpRequestException e)
            {
                Console.WriteLine("\nException Caught!");
                Console.WriteLine("Message :{0} ", e.Message);
            }

            return lstWebbedModels;
        }


        public List<WebbedModel> mockData()
        {
            List<WebbedModel> lstWebbedModels = new List<WebbedModel>();
            try
            {
                //Using mock because API service is not working// 
                using (StreamReader r = new StreamReader("Models/mock.json"))
                {
                    string json = r.ReadToEnd();
                    lstWebbedModels = JsonConvert.DeserializeObject<List<WebbedModel>>(json);
                }
            }
            catch (Exception e)
            {
                return null;
            }

            return lstWebbedModels;
        }
    }

}
