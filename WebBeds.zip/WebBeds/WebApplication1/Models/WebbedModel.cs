﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;
using WebApplication1.Common;

namespace WebApplication1.Models
{
    public class WebbedModel
    {
        public Hotel hotel { get; set; }
        public List<Rate> rates { get; set; }
    }
    public class Hotel
    {
        public string propertyID { get; set; }
        public string name { get; set; }
        public string geoId { get; set; }
        public string rating { get; set; }
    }

    public class Rate
    {
        public string rateType { get; set; }
        public string boardType { get; set; }
        public string value { get; set; }
    }

    public class Rootobject
    {
        public List<WebbedModel> webbedlst { get; set; }
        //After calculated list collection
        public List<WebbedModel> finalCollection { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public async Task<Rootobject> RetriveService()
        {
            Rootobject objRootobject = new Rootobject();
            BasicMethod objBasicMethod = new BasicMethod();
            List<WebbedModel> lstWebbedModels = new List<WebbedModel>();
            Hotel objHotel = new Hotel();
            List<Rate> lstRate = new List<Rate>();
            List<WebbedModel> FinalLstWebbedModel = new List<WebbedModel>();

            string url = "https://webbedsdevtest.azurewebsites.net/api/findBargain";
            int destinationId = 232;
            int nights = 4;
            string code = "YTUYtuii";
            lstWebbedModels = await objBasicMethod.CallApiService(url, destinationId, nights, code);

            foreach(var v in lstWebbedModels)
            {
                WebbedModel objWebbedModel = new WebbedModel();
                List<Rate> finalLstRate = new List<Rate>();

                objHotel = v.hotel;
                lstRate = v.rates.ToList();
                foreach(var r in lstRate)
                {
                    Rate finalRate = new Rate();

                    if (!string.IsNullOrWhiteSpace(r.rateType) && r.rateType == "PerNight")
                    {
                        finalRate.value = (Convert.ToDecimal(r.value) * nights).ToString();
                        finalRate.rateType = r.rateType;
                        finalRate.boardType = r.boardType;
                        finalLstRate.Add(finalRate);
                    }
                }

                objWebbedModel.hotel = objHotel;
                objWebbedModel.rates = finalLstRate.Count > 0 ? finalLstRate : lstRate;
                FinalLstWebbedModel.Add(objWebbedModel);
            }

            objRootobject.finalCollection = FinalLstWebbedModel;

            return objRootobject;
        }

    }
}